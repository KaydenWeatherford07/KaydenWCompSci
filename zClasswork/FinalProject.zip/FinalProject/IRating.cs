namespace CompSci.zClasswork.FinalProject;

public interface IRating
{
    void ValidateRating();
    double Rating {get;}
}